#include "LAB_3.c"

//Procedimiento Main que da el inicio al programa.
//Entrada: Vacia.
//Salida: Int 0 que representa que se termino la ejecucion del programa.
int main(){
    menu();
    printf("\n");
    return 0;
}